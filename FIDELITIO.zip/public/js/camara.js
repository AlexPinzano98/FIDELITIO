let scanner = new Instascan.Scanner({
    video: document.getElementById('preview'),
    scanPeriod: 4,
    mirror: false
});
scanner.addListener('scan', function(content) {
    alert('Contenido: ' + content);
    // sellar(content); 
});

function openCamara() {
    Instascan.Camera.getCameras().then(cameras => {
        //If a camera is detected
        if (cameras.length > 0) {
            //If the user has a rear/back camera
            if (cameras[1]) {
                //use that by default
                scanner.start(cameras[1]);
            } else {
                //else use front camera
                scanner.start(cameras[0]);
            }
        } else {
            //if no cameras are detected give error
            console.error('No cameras found.');
        }
    });
    document.getElementById('preview').style.display = "block";
}

function closeCamara() {
    scanner.stop();
    document.getElementById('preview').style.display = "none";
}