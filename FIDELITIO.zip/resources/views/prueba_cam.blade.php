<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="https://unpkg.com/@zxing/library@latest"></script>
    <script src="cam_libreria/prueba.js"></script>
    <title>Document</title>
</head>
<style>
#reader__status_span{
    display: none;
}
</style>
<body>
    <div style="width: 500px" id="reader">
    </div>
</body>
<script src="cam_libreria/html5-qrcode-scanner.js"></script>
    <script src="cam_libreria/html5-qrcode.js"></script>
</html>