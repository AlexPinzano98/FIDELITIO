<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TIPOS DE CRUD</title>
</head>
<body>

    <div id="permissions">
        <!-- <a href="{{ url('/crudCompany') }}">COMPAÑIAS</a> -->
        <a href="{{ url('/crudLocales_Grupo') }}">LOCALES</a>
        <a href="{{ url('/crudPromociones_Grupo') }}">PROMOCIONES</a>
        <a href="{{ url('/crudTarjetas_Grupo') }}">TARJETAS</a>
        <a href="{{ url('/crudUsuarios_Grupo') }}">USUARIOS</a>
    </div>

    <!-- <script src="js/permissionsAjax.js"></script> -->
</body>
</html>
